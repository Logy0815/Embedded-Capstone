/*
 * rtos.h
 *
 *  Created on: Nov 30, 2025
 *      Author: chool
 */

#ifndef RTOS_H
#define RTOS_H

#include <stdint.h>

#define MAX_TASKS   8

// ============================
// Task Control Block
// ============================
typedef struct {
    void (*func)(void *arg);
    void *arg;
    uint32_t period_ms;
    uint32_t next_run;
    uint8_t active;
} OS_Task_t;

// ============================
// Time Base
// ============================
extern volatile uint32_t time_ms;

// ============================
// Public RTOS Functions
// ============================
void Init(void);
int  AddPeriodicTask(void (*func)(void *), void *arg, uint32_t period_ms);
void Run(void);
void TickHandler(void);
void Delay(uint32_t delay_ms);

// ============================
// Message Queue for IPC
// ============================

#define QUEUE_SIZE 16

void Queue_Send(uint8_t msg);
uint8_t Queue_Receive(void);
uint8_t Queue_Available(void);

// ============================
// Mutex (very simple spinlock)
// ============================
void Mutex_Lock(volatile uint8_t *mtx);
void Mutex_Unlock(volatile uint8_t *mtx);

// ============================
// Event Flags
// ============================

extern volatile uint32_t event_flags;

void Event_Set(uint32_t flag);
void Event_Clear(uint32_t flag);
uint8_t Event_Check(uint32_t flag);

#endif // RTOS_H
