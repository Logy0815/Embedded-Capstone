/*
 * dwt_delay.h
 *
 *  Created on: Dec 3, 2025
 *      Author: chool
 */

#ifndef _DWT_DELAY_H_
#define _DWT_DELAY_H_

#include "main.h"

void DWT_Delay_Init(void);
void DWT_Delay_us(uint32_t us);

#endif /* INC_DWT_DELAY_H_ */
