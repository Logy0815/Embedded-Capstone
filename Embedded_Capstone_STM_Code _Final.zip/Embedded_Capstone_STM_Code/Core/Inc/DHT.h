/*
 * DHT.h
 *
 *  Created on: Dec 3, 2025
 *      Author: chool
 */

#ifndef _DHT_H_
#define _DHT_H_

#include "main.h"  // gives HAL + SystemCoreClock

// DHT11 on PB0
#define DHT_PORT GPIOB
#define DHT_PIN  GPIO_PIN_0

typedef enum {
    DHT_OK = 0,
    DHT_ERROR_TIMEOUT,
    DHT_ERROR_CHECKSUM
} DHT_StatusTypeDef;

void DHT_Init(void);
DHT_StatusTypeDef DHT_ReadTemperature(uint8_t *temperature);

#endif /* _DHT_H_ */
