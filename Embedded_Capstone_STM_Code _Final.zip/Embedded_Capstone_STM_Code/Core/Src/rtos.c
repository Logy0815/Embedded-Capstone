/*
 * rtos.c
 *
 *  Created on: Nov 30, 2025
 *      Author: chool
 */
/*
* rtos.c
* Minimal RTOS used for periodic scheduling + IPC
* Author: chool (updated by ChatGPT)
*/

#include "rtos.h"

volatile uint32_t time_ms = 0;
static OS_Task_t tasks[MAX_TASKS];

// ============================
// Event Flags
// ============================
volatile uint32_t event_flags = 0;

// ============================
// Message Queue
// ============================
static volatile uint8_t queue[QUEUE_SIZE];
static volatile uint8_t q_head = 0;
static volatile uint8_t q_tail = 0;
static volatile uint8_t q_count = 0;

// ============================
// Basic Delay
// ============================
void Delay(uint32_t delay_ms)
{
    uint32_t start = time_ms;
    while ((uint32_t)(time_ms - start) < delay_ms);
}

// ============================
// RTOS Init
// ============================
void Init(void)
{
    time_ms = 0;

    for (int i = 0; i < MAX_TASKS; i++)
        tasks[i].active = 0;

    // reset queue
    q_head = q_tail = q_count = 0;

    // reset events
    event_flags = 0;
}

// ============================
// Add Task
// ============================
int AddPeriodicTask(void (*func)(void *), void *arg, uint32_t period_ms)
{
    for (int i = 0; i < MAX_TASKS; i++) {
        if (!tasks[i].active) {
            tasks[i].func = func;
            tasks[i].arg = arg;
            tasks[i].period_ms = period_ms;
            tasks[i].next_run = time_ms + period_ms;
            tasks[i].active = 1;
            return i;
        }
    }
    return -1;
}

// ============================
// 1ms Tick from SysTick_Handler
// ============================
void TickHandler(void)
{
    time_ms++;
}

// ============================
// Scheduler Loop
// ============================
void Run(void)
{
    while (1)
    {
        for (int i = 0; i < MAX_TASKS; i++)
        {
            if (tasks[i].active)
            {
                int32_t diff = (int32_t)(time_ms - tasks[i].next_run);
                if (diff >= 0)
                {
                    tasks[i].func(tasks[i].arg);
                    tasks[i].next_run += tasks[i].period_ms;
                }
            }
        }
    }
}

// ============================
// MESSAGE QUEUE
// ============================
void Queue_Send(uint8_t msg)
{
    if (q_count < QUEUE_SIZE) {
        queue[q_head] = msg;
        q_head = (q_head + 1) % QUEUE_SIZE;
        q_count++;
    }
}

uint8_t Queue_Receive(void)
{
    if (q_count == 0)
        return 0;

    uint8_t val = queue[q_tail];
    q_tail = (q_tail + 1) % QUEUE_SIZE;
    q_count--;
    return val;
}

uint8_t Queue_Available(void)
{
    return q_count;
}

// ============================
// MUTEX
// ============================
void Mutex_Lock(volatile uint8_t *mtx)
{
    while (__atomic_test_and_set(mtx, __ATOMIC_ACQUIRE));
}

void Mutex_Unlock(volatile uint8_t *mtx)
{
    __atomic_clear(mtx, __ATOMIC_RELEASE);
}

// ============================
// EVENT FLAGS
// ============================
void Event_Set(uint32_t flag)
{
    event_flags |= flag;
}

void Event_Clear(uint32_t flag)
{
    event_flags &= ~flag;
}

uint8_t Event_Check(uint32_t flag)
{
    return (event_flags & flag) ? 1 : 0;
}
