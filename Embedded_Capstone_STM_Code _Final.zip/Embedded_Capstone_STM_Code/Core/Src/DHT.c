/*
 * DHT.c
 *
 *  Created on: Dec 3, 2025
 *      Author: chool
 */

#include "DHT.h"

/* ========= Local microsecond delay using DWT (private to this file) ========= */

static void DWT_Delay_Init(void)
{
    CoreDebug->DEMCR |= CoreDebug_DEMCR_TRCENA_Msk;  // enable trace
    DWT->CYCCNT = 0;
    DWT->CTRL |= DWT_CTRL_CYCCNTENA_Msk;             // enable cycle counter
}

static void DWT_Delay_us(uint32_t us)
{
    uint32_t start = DWT->CYCCNT;
    uint32_t ticks = us * (SystemCoreClock / 1000000U);
    while ((DWT->CYCCNT - start) < ticks);
}

/* =================== GPIO helpers (input / output mode) ===================== */

static void DHT_SetPinOutput(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin   = DHT_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_OUTPUT_OD;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_VERY_HIGH;
    HAL_GPIO_Init(DHT_PORT, &GPIO_InitStruct);
}

static void DHT_SetPinInput(void)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};
    GPIO_InitStruct.Pin   = DHT_PIN;
    GPIO_InitStruct.Mode  = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull  = GPIO_NOPULL;
    HAL_GPIO_Init(DHT_PORT, &GPIO_InitStruct);
}

/* =========================== Public init function =========================== */

void DHT_Init(void)
{
    static uint8_t dwt_inited = 0;

    if (!dwt_inited)
    {
        DWT_Delay_Init();   // ensure DWT is ready for us-delays
        dwt_inited = 1;
    }

    DHT_SetPinOutput();
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_SET); // idle high
}

/* ============================ Protocol helpers ============================== */

static DHT_StatusTypeDef DHT_Start(void)
{
    uint32_t timeout;

    // MCU pulls line low for at least 18 ms
    DHT_SetPinOutput();
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_RESET);
    HAL_Delay(20);

    // Then pull high for 20–40 µs
    HAL_GPIO_WritePin(DHT_PORT, DHT_PIN, GPIO_PIN_SET);
    DWT_Delay_us(30);

    // Release line, DHT takes over
    DHT_SetPinInput();

    // Wait for DHT to pull line low (~80 µs)
    timeout = 0;
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET)
    {
        DWT_Delay_us(1);
        if (++timeout > 300) return DHT_ERROR_TIMEOUT;
    }

    // Then high (~80 µs)
    timeout = 0;
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_RESET)
    {
        DWT_Delay_us(1);
        if (++timeout > 300) return DHT_ERROR_TIMEOUT;
    }

    // Then low again – start of data bits
    timeout = 0;
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET)
    {
        DWT_Delay_us(1);
        if (++timeout > 300) return DHT_ERROR_TIMEOUT;
    }

    return DHT_OK;
}

static uint8_t DHT_ReadBit(void)
{
    uint32_t timeout = 0;

    // Each bit starts with ~50 µs LOW
    while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_RESET)
    {
        DWT_Delay_us(1);
        if (++timeout > 300) break;
    }

    // Length of HIGH pulse encodes 0 or 1
    DWT_Delay_us(40); // sample in middle of high
    if (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET)
    {
        // Wait for line to go low again
        timeout = 0;
        while (HAL_GPIO_ReadPin(DHT_PORT, DHT_PIN) == GPIO_PIN_SET)
        {
            DWT_Delay_us(1);
            if (++timeout > 300) break;
        }
        return 1;
    }
    return 0;
}

static uint8_t DHT_ReadByte(void)
{
    uint8_t i, byte = 0;
    for (i = 0; i < 8; i++)
    {
        byte <<= 1;
        byte |= DHT_ReadBit();
    }
    return byte;
}

/* =========================== Public: temperature ============================ */

DHT_StatusTypeDef DHT_ReadTemperature(uint8_t *temperature)
{
    uint8_t rh_int, rh_dec, t_int, t_dec, checksum;

    DHT_StatusTypeDef status = DHT_Start();
    if (status != DHT_OK)
    {
        // If start failed, caller can decide what to do (e.g. force 0)
        return status;
    }

    // Read all 5 bytes but ignore checksum correctness
    rh_int   = DHT_ReadByte();
    rh_dec   = DHT_ReadByte();
    t_int    = DHT_ReadByte();
    t_dec    = DHT_ReadByte();
    checksum = DHT_ReadByte();   // read but ignore

    // Just return the integer temperature, no checksum validation
    if (temperature != NULL)
        *temperature = t_int;

    return DHT_OK;   // always OK if we got this far
}

